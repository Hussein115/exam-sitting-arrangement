-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 18, 2024 at 08:53 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `seatarrangerdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`email`, `password`, `name`, `phone`) VALUES
('arpita@gmail.com', '$2y$10$0uI9DpDiGcvhEUc6u7VS1ORhWHR2RDCjhRZsQpWuPXeVDqVm.UNyy', 'Arpita Das', '1212121212'),
('dhdh@gmail.com', '$2y$10$k.oImPrQmIUkpZvzbZWkPuKBBHInlsyC5nab2c6txln5HZ93fROnO', 'axy', '23343452');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `cid` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `capacity` int(11) DEFAULT NULL,
  `batch` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`cid`, `name`, `capacity`, `batch`) VALUES
(1, 'BCA', 60, '2021'),
(2, 'MCA', 30, '2021'),
(3, 'PGDCA', 100, '2021');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `rid` int(11) NOT NULL,
  `roomno` varchar(255) NOT NULL,
  `capacity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`rid`, `roomno`, `capacity`) VALUES
(1, '201', 60),
(2, '202', 60),
(3, '203', 60),
(4, '204', 80);

-- --------------------------------------------------------

--
-- Table structure for table `seat_plan`
--

CREATE TABLE `seat_plan` (
  `sid` int(11) NOT NULL,
  `rid` int(11) DEFAULT NULL,
  `examroll` varchar(255) NOT NULL,
  `row` varchar(255) DEFAULT NULL,
  `col` varchar(255) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `seat_plan`
--

INSERT INTO `seat_plan` (`sid`, `rid`, `examroll`, `row`, `col`, `cid`, `created_at`) VALUES
(1850, 1, '2100243', '1', '1', NULL, '2024-06-18 17:05:24'),
(1851, 1, '2111246', '1', '2', NULL, '2024-06-18 17:05:24'),
(1852, 1, '2111250', '1', '3', NULL, '2024-06-18 17:05:24'),
(1853, 1, '2111254', '1', '4', NULL, '2024-06-18 17:05:24'),
(1854, 1, '2100241', '2', '1', NULL, '2024-06-18 17:05:24'),
(1855, 1, '2100258', '2', '2', NULL, '2024-06-18 17:05:24'),
(1856, 1, '2111242', '2', '3', NULL, '2024-06-18 17:05:24'),
(1857, 1, '2111259', '2', '4', NULL, '2024-06-18 17:05:24'),
(1858, 1, '2100237', '3', '1', NULL, '2024-06-18 17:05:24'),
(1859, 1, '2100263', '3', '2', NULL, '2024-06-18 17:05:24'),
(1860, 1, '2111253', '3', '3', NULL, '2024-06-18 17:05:24'),
(1861, 1, '2111257', '3', '4', NULL, '2024-06-18 17:05:24'),
(1862, 1, '2100261', '4', '1', NULL, '2024-06-18 17:05:24'),
(1863, 1, '2111248', '4', '2', NULL, '2024-06-18 17:05:24'),
(1864, 1, '2100247', '4', '3', NULL, '2024-06-18 17:05:24'),
(1865, 1, '2111239', '4', '4', NULL, '2024-06-18 17:05:24'),
(1866, 1, '2111237', '5', '1', NULL, '2024-06-18 17:05:24'),
(1867, 1, '2111251', '5', '2', NULL, '2024-06-18 17:05:24'),
(1868, 1, '2100236', '5', '3', NULL, '2024-06-18 17:05:24'),
(1869, 1, '2100239', '5', '4', NULL, '2024-06-18 17:05:24'),
(1870, 1, '2111232', '6', '1', NULL, '2024-06-18 17:05:24'),
(1871, 1, '2111245', '6', '2', NULL, '2024-06-18 17:05:24'),
(1872, 1, '2111243', '6', '3', NULL, '2024-06-18 17:05:24'),
(1873, 1, '2100246', '6', '4', NULL, '2024-06-18 17:05:24'),
(1874, 1, '2111252', '7', '1', NULL, '2024-06-18 17:05:24'),
(1875, 1, '2100264', '7', '2', NULL, '2024-06-18 17:05:24'),
(1876, 1, '2100262', '7', '3', NULL, '2024-06-18 17:05:24'),
(1877, 1, '2100252', '7', '4', NULL, '2024-06-18 17:05:24'),
(1878, 1, '2111249', '8', '1', NULL, '2024-06-18 17:05:24'),
(1879, 1, '2100259', '8', '2', NULL, '2024-06-18 17:05:24'),
(1882, 2, '2100260', '1', '1', NULL, '2024-06-18 17:18:52'),
(1883, 2, '2100264', '1', '2', NULL, '2024-06-18 17:18:52'),
(1884, 2, '2111247', '1', '3', NULL, '2024-06-18 17:18:52'),
(1885, 2, '2100261', '2', '1', NULL, '2024-06-18 17:18:52'),
(1886, 2, '2111237', '2', '2', NULL, '2024-06-18 17:18:52'),
(1887, 2, '2100263', '2', '3', NULL, '2024-06-18 17:18:52'),
(1888, 2, '2100258', '3', '1', NULL, '2024-06-18 17:18:52'),
(1889, 2, '2100236', '3', '2', NULL, '2024-06-18 17:18:52'),
(1890, 2, '2100242', '3', '3', NULL, '2024-06-18 17:18:52'),
(1891, 2, '2111256', '4', '1', NULL, '2024-06-18 17:18:52');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `name` varchar(255) NOT NULL,
  `examroll` varchar(255) NOT NULL,
  `cid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`name`, `examroll`, `cid`) VALUES
('Arpita', '2100233', 1),
('Student2', '2100234', 1),
('Student1', '2100235', 1),
('Student2', '2100236', 1),
('Student1', '2100237', 1),
('Student2', '2100238', 1),
('Student1', '2100239', 1),
('Student2', '2100240', 1),
('Student1', '2100241', 1),
('Student2', '2100242', 1),
('Student1', '2100243', 1),
('Student2', '2100245', 1),
('Student1', '2100246', 1),
('Student2', '2100247', 1),
('Student1', '2100248', 1),
('Student2', '2100249', 1),
('Student1', '2100250', 1),
('Student2', '2100251', 1),
('Student1', '2100252', 1),
('Student2', '2100253', 1),
('Student1', '2100254', 1),
('Student1', '2100255', 1),
('Student1', '2100256', 1),
('Student1', '2100257', 1),
('Student1', '2100258', 1),
('Student1', '2100259', 1),
('Student1', '2100260', 1),
('Student1', '2100261', 1),
('Student1', '2100262', 1),
('Student1', '2100263', 1),
('Student1', '2100264', 1),
('Student1', '2100265', 1),
('Student1', '2111230', 2),
('Student1', '2111231', 2),
('Student1', '2111232', 2),
('Student1', '2111233', 2),
('Student1', '2111234', 2),
('Student1', '2111235', 2),
('Student1', '2111236', 2),
('Student1', '2111237', 2),
('Student1', '2111238', 2),
('Student1', '2111239', 2),
('Student1', '2111240', 2),
('Student1', '2111241', 2),
('Student1', '2111242', 2),
('Student1', '2111243', 2),
('Student1', '2111244', 2),
('Student1', '2111245', 2),
('Student1', '2111246', 2),
('Student1', '2111247', 2),
('Student1', '2111248', 2),
('Student1', '2111249', 2),
('Student1', '2111250', 2),
('Student1', '2111251', 2),
('Student1', '2111252', 2),
('Student1', '2111253', 2),
('Student1', '2111254', 2),
('Student1', '2111255', 2),
('Student1', '2111256', 2),
('Student1', '2111257', 2),
('Student1', '2111258', 2),
('Student1', '2111259', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `seat_plan`
--
ALTER TABLE `seat_plan`
  ADD PRIMARY KEY (`sid`),
  ADD KEY `rid` (`rid`),
  ADD KEY `examroll` (`examroll`),
  ADD KEY `cid` (`cid`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`examroll`),
  ADD KEY `cid` (`cid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `seat_plan`
--
ALTER TABLE `seat_plan`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1892;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `seat_plan`
--
ALTER TABLE `seat_plan`
  ADD CONSTRAINT `seat_plan_ibfk_1` FOREIGN KEY (`rid`) REFERENCES `rooms` (`rid`),
  ADD CONSTRAINT `seat_plan_ibfk_2` FOREIGN KEY (`examroll`) REFERENCES `students` (`examroll`),
  ADD CONSTRAINT `seat_plan_ibfk_3` FOREIGN KEY (`cid`) REFERENCES `courses` (`cid`);

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`cid`) REFERENCES `courses` (`cid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
