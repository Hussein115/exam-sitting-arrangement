<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SeatScheduler</title>
    <link rel="stylesheet" href="../css/navbar.css">
</head>
<body>
<nav>
    <div class="nav-container">
            <div class="navbar-brand">
                <h1>ArrangeEd</h1>
            </div>
            <div class="navbar-links">
                <a href="register.php" class="btn btn-alt">Sign Up</a>
            </div>
        </div>
    </nav>
</body>
</html>
